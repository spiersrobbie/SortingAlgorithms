﻿using System.Collections.Generic;
using System;

namespace SortingAlgorithms
{
    class Program
    {
        static void Main(string[] args)
        {
            int amountOfIterations = 100;
            int maxLength = 1000000;
            int maxNumber = 100000;

            //List<double> selectionTimes = new List<double>();
            //List<double> insertionTimes = new List<double>();
            List<double> radixLSDTimes = new List<double>();
            List<double> quicksortTimes = new List<double>();
            List<double> mergeTimes = new List<double>();
            //List<double> bubbleTimes = new List<double>();
            //List<double> cocktailTimes = new List<double>();
            List<double> bucketTimes = new List<double>();


            var watch = System.Diagnostics.Stopwatch.StartNew();

            for (int length = maxLength / 100; length <= maxLength; length += maxLength / 100)
            {
                Console.WriteLine(String.Format("Algorithm speeds for {0} iterations, array length of {1}, and maximum number of {2}", amountOfIterations, length, maxNumber));

                //for (int i = 0; i < amountOfIterations; i++)
                //{
                //    SelectionSort(RandomGenerator(length, maxNumber));
                //}
                //selectionTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                //Console.WriteLine(watch.ElapsedMilliseconds / 1000.0 + "  :  " + length + "  :  Selection Sort");
                //watch.Restart();

                //for (int i = 0; i < amountOfIterations; i++)
                //{
                //    InsertionSort(RandomGenerator(length, maxNumber));
                //}
                //insertionTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                //Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  Insertion Sort");
                //watch.Restart();

                for (int i = 0; i < amountOfIterations; i++)
                {
                    RadixLSD(RandomGenerator(length, maxNumber));
                }
                radixLSDTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  Radix LSD Sort");
                watch.Restart();

                for (int i = 0; i < amountOfIterations; i++)
                {
                    QuickSort(RandomGenerator(length, maxNumber));
                }
                quicksortTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  QuickSort");
                watch.Restart();

                for (int i = 0; i < amountOfIterations; i++)
                {
                    MergeSort(RandomGenerator(length, maxNumber));
                }
                mergeTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  Merge Sort");
                watch.Restart();

                //for (int i = 0; i < amountOfIterations; i++)
                //{
                //    TraditionalBubbleSort(RandomGenerator(length, maxNumber));
                //}
                //bubbleTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                //Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  Bubble Sort");
                //watch.Restart();

                //for (int i = 0; i < amountOfIterations; i++)
                //{
                //    CocktailShaker(RandomGenerator(length, maxNumber));
                //}
                //cocktailTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                //Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  Cocktail Shaker Sort");
                //watch.Restart();

                for (int i = 0; i < amountOfIterations; i++)
                {
                    RecursiveBucketSort(RandomGenerator(length, maxNumber));
                }
                bucketTimes.Add(watch.ElapsedMilliseconds / 1000.0);
                Console.WriteLine(watch.Elapsed + "  :  " + length + "  :  Recursive Bucket Sort");
                watch.Restart();
            }

            //Console.WriteLine("Selection Sort Times:");
            //WriteList(selectionTimes);
            //Console.WriteLine("Insertion Sort Times:");
            //WriteList(insertionTimes);
            Console.WriteLine("Radix LSD Sort Times:");
            WriteList(radixLSDTimes);
            Console.WriteLine("QuickSort Times:");
            WriteList(quicksortTimes);
            Console.WriteLine("Merge Sort Times:");
            WriteList(mergeTimes);
            //Console.WriteLine("Bubble Sort Times:");
            //WriteList(bubbleTimes);
            //Console.WriteLine("Cocktail Sort Times:");
            //WriteList(cocktailTimes);
            Console.WriteLine("Bucket Sort Times:");
            WriteList(bucketTimes);



            Console.ReadKey();
        }
        
        public static int[] TraditionalBubbleSort(int[] unsortedInts)
        {
            int[] previousSort = new int[unsortedInts.Length];

            for (int iteration = 0; iteration < unsortedInts.Length - 1; iteration++)
            {
                for (int i = 0; i < unsortedInts.Length; i++)
                {
                    previousSort[i] = unsortedInts[i];
                }

                for (int ndx = 0; ndx < unsortedInts.Length - 1; ndx++)
                {
                    int leftSide = unsortedInts[ndx];
                    int rightSide = unsortedInts[ndx + 1];
                    if (leftSide > rightSide)
                    {
                        unsortedInts[ndx] = rightSide;
                        unsortedInts[ndx + 1] = leftSide;
                    }
                }

                bool arrIsSorted = true;
                for (int i = 0; i < unsortedInts.Length; i++)
                {
                    if (unsortedInts[i] != previousSort[i])
                    {
                        arrIsSorted = false;
                    }
                }
                if (arrIsSorted == true)
                {
                    return unsortedInts;
                }
            }
            return unsortedInts;
        }

        public static int[] SelectionSort(int[] unsortedInts)
        {
            int[] sortedInts = new int[unsortedInts.Length];

            for (int ndx = 0; ndx < unsortedInts.Length - 2; ndx++)
            {
                int correctIndex = -32;
                int smallestNumber = unsortedInts[ndx];
                for (int ndy = ndx; ndy < unsortedInts.Length; ndy++)
                {
                    if (smallestNumber > unsortedInts[ndy])
                    {
                        smallestNumber = unsortedInts[ndy];
                        correctIndex = ndy;
                    }
                }
                if (correctIndex == -32)
                {
                    correctIndex = ndx;
                }
                unsortedInts[correctIndex] = unsortedInts[ndx];
                unsortedInts[ndx] = smallestNumber;
            }
            return unsortedInts;
        }
        
        public static int[] InsertionSort(int[] unsortedArray)
        {

            for (int indexOfRight = 1; indexOfRight < unsortedArray.Length; indexOfRight++)
            {
                int valueOfLeft = unsortedArray[indexOfRight];
                int indexOfLeft = indexOfRight;
                int valueOfRight = unsortedArray[indexOfRight];

                

                for (int panLeftSide = indexOfRight - 1; panLeftSide >= 0; panLeftSide--)
                {
                    if (unsortedArray[panLeftSide] < unsortedArray[indexOfRight])
                    {
                        indexOfLeft = panLeftSide + 1;
                        valueOfLeft = unsortedArray[indexOfLeft];
                        break;
                    }

                }
                if (indexOfLeft == indexOfRight && unsortedArray[indexOfRight] < unsortedArray[indexOfRight - 1])
                {
                    indexOfLeft = 0;
                    valueOfLeft = unsortedArray[0];
                }

                if (indexOfLeft != indexOfRight)
                {
                    for (int panRightSide = indexOfRight; panRightSide > indexOfLeft; panRightSide--)
                    {
                        unsortedArray[panRightSide] = unsortedArray[panRightSide - 1];
                    }
                    unsortedArray[indexOfLeft] = valueOfRight;
                }
            }

            return unsortedArray;
        }

        public static int[] RadixLSD(int[] arr)
        {
            int maxNumber = 0;
            foreach (int num in arr)
            {
                if (num > maxNumber)
                {
                    maxNumber = num;
                }
            }

            string[] paddedInts = new string[arr.Length];
            for (int ndx = 0; ndx < arr.Length; ndx++)
            {
                string toString = arr[ndx].ToString();
                bool isPadded = false;
                while (!isPadded)
                {
                    if (toString.Length > (int)(Math.Log10(maxNumber)))
                    {
                        isPadded = true;
                    }
                    else
                    {
                        toString = "0" + toString;
                    }
                }
                paddedInts[ndx] = toString;
            }

            int[,] multi = new int[(int)Math.Log10(maxNumber) + 2, arr.Length];

            for (int ndy = 0; ndy < multi.GetLength(1); ndy++)
            {
                multi[multi.GetLength(0) - 1, ndy] = arr[ndy];
            }
            for (int ndx = 0; ndx < Math.Log10(maxNumber); ndx++)
            {
                for (int ndy = 0; ndy < arr.Length; ndy++)
                {
                    int test1 = int.Parse(((paddedInts[ndy])[ndx]).ToString());
                    multi[ndx, ndy] = test1;
                }
            }



            for (int ndx = multi.GetLength(0) - 2; ndx >= 0; ndx--)
            {
                int[,] tempMulti = new int[multi.GetLength(0), multi.GetLength(1)];
                int[] count = new int[10];
                for (int ndy = 0; ndy < multi.GetLength(1); ndy++)
                {
                    count[multi[ndx, ndy]]++;
                }
                for (int ndy = 1; ndy < count.Length; ndy++)
                {
                    count[ndy] += count[ndy - 1];
                }

                for (int ndy = multi.GetLength(1) - 1; ndy >= 0; ndy--)
                {
                    for (int mbx = 0; mbx < multi.GetLength(0); mbx++)
                    {

                        tempMulti[mbx, count[multi[ndx, ndy]] - 1] = multi[mbx, ndy];
                    }
                    count[multi[ndx, ndy]]--;
                }
                multi = tempMulti;
            }

            for (int ndy = 0; ndy < multi.GetLength(1); ndy++)
            {
                arr[ndy] = multi[multi.GetLength(0) - 1, ndy];
            }

            return arr;
        }

        public static int[] QuickSort(int[] inputArray)
        {
            bool areRepeatingNums = true;
            int length = inputArray.Length;

            for (int ndx = 1; ndx < inputArray.Length; ndx++)
            {
                if (inputArray[0] != inputArray[ndx])
                {
                    areRepeatingNums = false;
                }
            }

            if (length == 1 || areRepeatingNums)
            {
                return inputArray;
            }

            int[] smallerArray = new int[length];
            int[] largerArray = new int[length];

            int min = inputArray[0];
            int max = inputArray[0];

            foreach (int number in inputArray)
            {
                if (number > max)
                {
                    max = number;
                }
                else if (number < min)
                {
                    min = number;
                }
            }

            int evaluee = ((max - min) / 2) + min;

            int ndLow = 0;
            int ndHigh = 0;
            foreach (int input in inputArray)
            {
                if (input > evaluee)
                {
                    largerArray[ndHigh] = input;
                    ndHigh++;
                }
                else
                {
                    smallerArray[ndLow] = input;
                    ndLow++;
                }
            }
            

            int smallerNonZeros = 0;
            int largerNonZeros = 0;
            for (int i = 0; i < smallerArray.Length; i++)
            {
                smallerNonZeros += (smallerArray[i] != 0) ? 1 : 0;
                largerNonZeros += (largerArray[i] != 0) ? 1 : 0;
            }

            int[] smallerShrunk = new int[smallerNonZeros];
            int[] largerShrunk = new int[largerNonZeros];

            int index = 0;
            for (int j = 0; j < smallerArray.Length; j++)
            {
                if (smallerArray[j] != 0)
                {
                    smallerShrunk[index] = smallerArray[j];
                    index++;
                }
            }

            index = 0;
            for (int j = 0; j < largerArray.Length; j++)
            {
                if (largerArray[j] != 0)
                {
                    largerShrunk[index] = largerArray[j];
                    index++;
                }
            }


            int[] sortedLow = QuickSort(smallerShrunk);
            int[] sortedHigh = QuickSort(largerShrunk);
            int[] sortedArray = new int[length];

            for (int ndx = 0; ndx < sortedLow.Length; ndx++)
            {
                sortedArray[ndx] = sortedLow[ndx];
            }
            for (int ndy = 0; ndy < sortedHigh.Length; ndy++)
            {
                sortedArray[ndy + sortedLow.Length] = sortedHigh[ndy];
            }

            return sortedArray;
        }
        
        public static int[] MergeSort(int[] arr)
        {
            if (arr.Length == 1)
            {
                return arr;
            }

            int[] leftArr = new int[arr.Length / 2];
            int[] rightArr = new int[(arr.Length / 2) + (arr.Length % 2)];

            for (int ndx = 0; ndx < arr.Length; ndx++)
            {
                if ((ndx) / leftArr.Length == 0)
                {
                    leftArr[ndx] = arr[ndx];
                }
                else
                {
                    rightArr[ndx - leftArr.Length] = arr[ndx];
                }
            }

            leftArr = MergeSort(leftArr);
            rightArr = MergeSort(rightArr);

            int comparedRightIndex = 0;
            int comparedLeftIndex = 0;

            for (int ndx = 0; ndx < arr.Length; ndx++)
            {
                if (leftArr[comparedLeftIndex] <= rightArr[comparedRightIndex])
                {
                    arr[ndx] = leftArr[comparedLeftIndex];
                    if (comparedLeftIndex < leftArr.Length - 1)
                    {
                        comparedLeftIndex++;
                    }
                    else
                    {
                        for (int ndw = 1; comparedRightIndex < rightArr.Length; ndw++)
                        {
                            arr[ndx + ndw] = rightArr[comparedRightIndex];
                            comparedRightIndex++;
                        }
                        return arr;
                    }
                }
                else
                {
                    arr[ndx] = rightArr[comparedRightIndex];
                    if (comparedRightIndex < rightArr.Length - 1)
                    {
                        comparedRightIndex++;
                    }
                    else
                    {
                        for (int ndw = 1; comparedLeftIndex < leftArr.Length; ndw++)
                        {
                            arr[ndx + ndw] = leftArr[comparedLeftIndex];
                            comparedLeftIndex++;
                        }
                        return arr;
                    }
                }
            }
            return arr;
        }

        public static int[] CocktailShaker(int[] arr)
        {
            for (int i = 0; i < arr.Length / 2; i++)
            {
                int[] lastSortedArr = arr;
                int index = 0;

                while (index < arr.Length - 1 - i)
                {
                    if (arr[index] > arr[index + 1])
                    {
                        int rightSide = arr[index + 1];
                        arr[index + 1] = arr[index];
                        arr[index] = rightSide;
                    }
                    index++;
                }
                while (index > i)
                {
                    if (arr[index] < arr[index - 1])
                    {
                        int rightSide = arr[index];
                        arr[index] = arr[index - 1];
                        arr[index - 1] = rightSide;
                    }
                    index--;
                }
            }
            return arr;
        }

        public static int[] RecursiveBucketSort(int[] arr)
        {

            bool allNumsAreSame = true;
            foreach (int number in arr)
            {
                if (arr[0] != number)
                {
                    allNumsAreSame = false;
                }
            }
            if (allNumsAreSame == true || arr.Length == 0)
            {
                return arr;
            }


            int amountOfBuckets = (int)Math.Pow(arr.Length, 0.5) + 1;

            int lengthOfBucket = arr.Length / amountOfBuckets * 5 + 1;
            int maxBucket = amountOfBuckets;
            int[,] buckets = new int[amountOfBuckets, lengthOfBucket];

            int maxNumber = 0;
            int minNumber = arr[0];
            foreach (int number in arr)
            {
                if (number > maxNumber)
                {
                    maxNumber = number;
                }
                if (number < minNumber)
                {
                    minNumber = number;
                }
            }

            maxNumber++;
            double bucketIncrement = (maxNumber - minNumber) / (double)amountOfBuckets;
            for (int currentBucket = 0; currentBucket < amountOfBuckets; currentBucket++)
            {
                int ndx = 0;
                foreach (int number in arr)
                {
                    if (number < (bucketIncrement * (1 + currentBucket)) + minNumber && number >= (bucketIncrement * currentBucket) + minNumber)
                    {
                        buckets[currentBucket, ndx] = number;
                        ndx++;
                    }
                }
            }


            int[,] cleanBuckets = new int[buckets.GetLength(0), buckets.GetLength(1)];

            for (int i = 0; i < buckets.GetLength(0); i++)
            {
                int amountOfNonzeros = 0;
                for (int y = 0; y < buckets.GetLength(1); y++)
                {
                    if (buckets[i, y] != 0)
                    {
                        amountOfNonzeros++;
                    }
                }

                int[] dirtyArray = new int[amountOfNonzeros];

                int indexOfDirty = 0;
                for (int y = 0; y < buckets.GetLength(1); y++)
                {
                    if (buckets[i, y] != 0)
                    {
                        dirtyArray[indexOfDirty] = buckets[i, y];
                        indexOfDirty++;
                    }
                }


                int[] cleanArray = RecursiveBucketSort(dirtyArray);

                for (int j = 0; j < cleanArray.Length; j++)
                {
                    cleanBuckets[i, j] = cleanArray[j];
                }
            }


            List<int> returnList = new List<int>();
            for (int bucketNumber = 0; bucketNumber < cleanBuckets.GetLength(0); bucketNumber++)
            {
                for (int indexNumber = 0; indexNumber < cleanBuckets.GetLength(1); indexNumber++)
                {
                    if (cleanBuckets[bucketNumber, indexNumber] != 0)
                    {
                        returnList.Add(cleanBuckets[bucketNumber, indexNumber]);
                    }
                }
            }

            int[] returnArray = new int[returnList.Count];
            returnList.CopyTo(returnArray);

            return returnArray;
        }

        public static int[] RandomGenerator(int length, int maxNumber)
        {
            int[] randomArray = new int[length];
            Random randomInt = new Random();

            for (int ndx = 0; ndx < length; ndx++)
            {
                randomArray[ndx] = randomInt.Next(1, maxNumber + 1);
            }
            return randomArray;
        }

        public static void WriteLine(int[] integerArray)
        {
            string writeLine = "";
            foreach (int number in integerArray)
            {
                writeLine += number + ", ";
            }
            Console.WriteLine(writeLine);
        }

        public static void WriteList(List<double> times)
        {
            string output = "";
            foreach (double time in times)
            {
                output += time + ", ";
            }
            Console.WriteLine(output);
        }
    }
}
